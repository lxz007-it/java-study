package com.lagou.springboot04_thymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot04ThymeleafApplicationTests {

    @Test
    void contextLoads() {
    }

}
