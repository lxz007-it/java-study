package com.lagou.enums;

/**
 * sql类型枚举
 * @author liuxingzhu
 */
public enum SqlTypeEnum {
    SELECT("select"),
    DELETE("delete"),
    INSERT("insert"),
    UPDATE("update");

    private SqlTypeEnum(String name){
        name=name;
    }

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
