package com.lagou.edu.annotation;

public @interface Service {

    String value();


}
