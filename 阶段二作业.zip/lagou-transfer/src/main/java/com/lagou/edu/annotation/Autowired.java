package com.lagou.edu.annotation;

/**
 * @author liuxingzhu
 * @date 2020-03-10 11:24
 */
public @interface Autowired {
    String value();
}
